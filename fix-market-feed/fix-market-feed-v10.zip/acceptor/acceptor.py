import quickfix as fix
import logging
import sys
import time
import uuid
import os
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [ACCEPTOR] %(levelname)s %(message)s"
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional RT publishing — only imported when RT_ENABLED=true
# ---------------------------------------------------------------------------
RT_ENABLED = os.environ.get("RT_ENABLED", "false").lower() == "true"

if RT_ENABLED:
    try:
        import pykx as kx
        from rtpy import Publisher, RTParams
        logger.info("RT publishing enabled (rtpy + pykx loaded)")
    except ImportError as e:
        logger.error(f"RT_ENABLED=true but import failed: {e}")
        sys.exit(1)
else:
    logger.info("RT publishing disabled — running in log-only mode (set RT_ENABLED=true to enable)")


class MarketDataAcceptor(fix.Application):
    """
    FIX Acceptor — receives Trade (AE) and Quote (S) messages
    from the initiator, parses them, and optionally publishes to KDB Insights
    Reliable Transport via the rtpy Publisher.

    RT publishing is controlled by the RT_ENABLED environment variable.
    When disabled, messages are parsed and logged only — useful for local dev/testing.
    """

    def __init__(self, rt_publisher=None):
        super().__init__()
        self.pub = rt_publisher   # None when RT is disabled

    def onCreate(self, sessionID):
        logger.info(f"Session created: {sessionID}")

    def onLogon(self, sessionID):
        logger.info(f"Logon: {sessionID}")

    def onLogout(self, sessionID):
        logger.info(f"Logout: {sessionID}")

    def toAdmin(self, message, sessionID):
        pass

    def fromAdmin(self, message, sessionID):
        pass

    def toApp(self, message, sessionID):
        pass

    def fromApp(self, message, sessionID):
        msgType = fix.MsgType()
        message.getHeader().getField(msgType)

        if msgType.getValue() == fix.MsgType_Quote:   # 'S'
            self._parse_quote(message)
        elif msgType.getValue() == "AE":              # Trade Capture Report
            self._parse_trade(message)
        else:
            logger.warning(f"Unhandled message type: {msgType.getValue()}")

    # ------------------------------------------------------------------
    # Quote (S) -> RT stream "quote"
    # ------------------------------------------------------------------

    def _parse_quote(self, message):
        symbol    = fix.Symbol();    message.getField(symbol)
        bidPx     = fix.BidPx();     message.getField(bidPx)
        offerPx   = fix.OfferPx();   message.getField(offerPx)
        bidSize   = fix.BidSize();   message.getField(bidSize)
        offerSize = fix.OfferSize(); message.getField(offerSize)

        now = datetime.utcnow()

        logger.info(
            f"[QUOTE] sym={symbol.getValue()} time={now.isoformat()} "
            f"bid={bidPx.getValue():.4f} bsize={bidSize.getValue()} "
            f"ask={offerPx.getValue():.4f} asize={offerSize.getValue()}"
        )

        if self.pub is not None:
            data = kx.Table(
                [[kx.TimestampAtom(now), symbol.getValue(), bidPx.getValue(),
                  offerPx.getValue(), bidSize.getValue(), offerSize.getValue()]],
                columns=['time', 'sym', 'bid', 'ask', 'bsize', 'asize']
            )
            self.pub("quote", data)
            logger.info("[QUOTE] Published to RT stream 'quote'")

    # ------------------------------------------------------------------
    # Trade (AE) -> RT stream "trade"
    # ------------------------------------------------------------------

    def _parse_trade(self, message):
        symbol  = fix.Symbol();   message.getField(symbol)
        lastPx  = fix.LastPx();   message.getField(lastPx)
        lastQty = fix.LastQty();  message.getField(lastQty)
        side    = fix.Side();     message.getField(side)

        now      = datetime.utcnow()
        side_str = "buy" if side.getValue() == fix.Side_BUY else "sell"

        logger.info(
            f"[TRADE] sym={symbol.getValue()} time={now.isoformat()} "
            f"px={lastPx.getValue():.4f} qty={lastQty.getValue()} side={side_str}"
        )

        if self.pub is not None:
            trade_id = uuid.uuid4()
            data = kx.Table(
                [[kx.TimestampAtom(now), symbol.getValue(), side_str,
                  lastPx.getValue(), lastQty.getValue(), trade_id]],
                columns=['time', 'sym', 'side', 'price', 'size', 'tradeID']
            )
            self.pub("trade", data)
            logger.info("[TRADE] Published to RT stream 'trade'")


def main():
    config_file = "/app/config/acceptor.cfg"

    if RT_ENABLED:
        # RT connection params — host/port/stream read from environment variables
        # so they can be overridden in docker-compose without rebuilding the image.
        rt_host   = os.environ.get("RT_HOST",   "rt-data-0")
        rt_port   = int(os.environ.get("RT_PORT",   "5002"))
        rt_stream = os.environ.get("RT_STREAM", "data")
        rt_prefix = os.environ.get("RT_PREFIX", "rt-")

        rt_params = RTParams(
            prefix=rt_prefix,
            stream=rt_stream,
            rt_dir='/tmp/tmprt'
        )
        # Write rt_client.json from env vars using the format required by the KDB Insights SDK.
        # Per the docs, the config file must use "insert" for the RT endpoint and "useSslRt": false
        # when connecting from inside the cluster without TLS.
        import json, pathlib
        client_cfg = {
            "useSslRt": False,
            "insert": [{"host": rt_host, "port": rt_port}],
            "stream": f"{rt_prefix}{rt_stream}"
        }
        cfg_path = pathlib.Path('/tmp/rt_client.json')
        cfg_path.write_text(json.dumps(client_cfg))
        rt_params = RTParams(
            config_url=f'file://{cfg_path}',
            rt_dir='/tmp/tmprt'
        )
        logger.info(f"Connecting to RT at {rt_host}:{rt_port} stream={rt_prefix}{rt_stream}")
        # Publisher opened once for the lifetime of the process;
        # cleanly disconnected when the with-block exits.
        with Publisher(rt_params) as pub:
            _run_acceptor(config_file, rt_publisher=pub)
    else:
        _run_acceptor(config_file, rt_publisher=None)


def _run_acceptor(config_file: str, rt_publisher):
    try:
        settings     = fix.SessionSettings(config_file)
        application  = MarketDataAcceptor(rt_publisher)
        storeFactory = fix.FileStoreFactory(settings)
        logFactory   = fix.FileLogFactory(settings)
        acceptor     = fix.SocketAcceptor(application, storeFactory, settings, logFactory)

        logger.info("Starting FIX acceptor...")
        acceptor.start()

        while True:
            time.sleep(1)

    except (fix.ConfigError, fix.RuntimeError) as e:
        logger.error(f"FIX error: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        logger.info("Shutting down acceptor...")
        acceptor.stop()


if __name__ == "__main__":
    main()
